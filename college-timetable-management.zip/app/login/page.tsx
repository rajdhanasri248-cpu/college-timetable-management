"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowUpRight, Sparkles } from "lucide-react";
import Link from "next/link";
import { SetupLanding } from "@/components/setup-landing";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";

export default function LoginPage() {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setMessage("");

    try {
      const supabase = createSupabaseBrowserClient();
      if (mode === "signup") {
        const { data, error: authError } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { name: displayName }, emailRedirectTo: `${window.location.origin}/auth/callback` },
        });
        if (authError) throw authError;
        if (!data.session) setMessage("Check your inbox to confirm your email, then come back to sign in.");
        else window.location.assign("/");
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
        if (authError) throw authError;
        window.location.assign("/");
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Authentication failed. Try again.");
    } finally {
      setBusy(false);
    }
  }

  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
    return <SetupLanding message="Add Supabase credentials before signing in." />;
  }

  return (
    <main className="auth-page">
      <Link className="auth-back" href="/"><ArrowLeft size={15} /> Back to DOTS</Link>
      <div className="auth-atmosphere" />
      <motion.section className="auth-panel" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <div className="auth-brand"><span><Sparkles size={17} /></span><strong>DOTS</strong></div>
        <div className="auth-copy"><span className="eyebrow">YOUR PERSONAL TEAM</span><h1>{mode === "signin" ? "Welcome back." : "Make room for more."}</h1><p>{mode === "signin" ? "Your companions are right where you left them." : "Create an account and meet your Dots."}</p></div>
        <form onSubmit={submit} className="auth-form">
          {mode === "signup" && <label>Your name<input autoComplete="name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} required maxLength={60} /></label>}
          <label>Email address<input type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required /></label>
          <label>Password<input type="password" autoComplete={mode === "signin" ? "current-password" : "new-password"} value={password} onChange={(event) => setPassword(event.target.value)} minLength={8} required /></label>
          {error && <p className="auth-error" role="alert">{error}</p>}
          {message && <p className="auth-message" role="status">{message}</p>}
          <button className="auth-submit" disabled={busy}>{busy ? "Connecting..." : mode === "signin" ? "Sign in" : "Create account"}<ArrowUpRight size={15} /></button>
        </form>
        <p className="auth-switch">{mode === "signin" ? "New around here?" : "Already have an account?"}<button onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(""); setMessage(""); }}>{mode === "signin" ? "Create an account" : "Sign in"}</button></p>
        <p className="auth-privacy">Your Dots and conversations belong to you. Nothing is shared across accounts.</p>
      </motion.section>
    </main>
  );
}