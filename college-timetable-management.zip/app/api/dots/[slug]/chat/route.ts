import OpenAI from "openai";
import { z } from "zod";
import { executeNovaTool, novaTools } from "@/lib/ai/nova-tools";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { createSupabaseServerClient } from "@/lib/supabase/server";

const messageSchema = z.object({
  message: z.string().trim().min(1).max(4000),
  conversationId: z.string().uuid().optional(),
  createNew: z.boolean().optional(),
});

type RouteContext = { params: Promise<{ slug: string }> };

async function getOwnedDot(slug: string) {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
    return { response: Response.json({ error: "Supabase is not configured. Add its URL and anon key to .env.local." }, { status: 503 }) };
  }

  const supabase = await createSupabaseServerClient();
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return { response: Response.json({ error: "Sign in to continue." }, { status: 401 }) };

  const { data: dot, error } = await supabase.from("dots").select("id,user_id,name,slug,role,description,color,system_instructions,status").eq("user_id", user.id).eq("slug", slug).single();
  if (error || !dot) return { response: Response.json({ error: "That Dot was not found in your account." }, { status: 404 }) };
  return { supabase, user, dot };
}

export async function GET(_request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const owned = await getOwnedDot(slug);
  if ("response" in owned) return owned.response;

  const { data: conversation } = await owned.supabase.from("conversations").select("id").eq("user_id", owned.user.id).eq("dot_id", owned.dot.id).order("updated_at", { ascending: false }).limit(1).maybeSingle();
  if (!conversation) return Response.json({ conversationId: null, messages: [] });

  const { data: messages, error } = await owned.supabase.from("messages").select("id,role,content").eq("user_id", owned.user.id).eq("conversation_id", conversation.id).order("created_at", { ascending: true }).limit(80);
  if (error) return Response.json({ error: "Conversation could not be loaded." }, { status: 500 });
  return Response.json({ conversationId: conversation.id, messages: messages ?? [] });
}

export async function POST(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const owned = await getOwnedDot(slug);
  if ("response" in owned) return owned.response;
  if (!process.env.OPENAI_API_KEY || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return Response.json({ error: "Server AI credentials are not configured. No message was sent." }, { status: 503 });
  }

  const parsed = messageSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Enter a message under 4,000 characters." }, { status: 400 });

  const { message, conversationId, createNew } = parsed.data;
  const { user, dot, supabase } = owned;
  const conversation = createNew
    ? { data: null }
    : conversationId
    ? await supabase.from("conversations").select("id,title").eq("id", conversationId).eq("user_id", user.id).eq("dot_id", dot.id).maybeSingle()
    : await supabase.from("conversations").select("id,title").eq("user_id", user.id).eq("dot_id", dot.id).order("updated_at", { ascending: false }).limit(1).maybeSingle();

  let activeConversation = conversation.data;
  if (conversationId && !activeConversation) return Response.json({ error: "Conversation not found." }, { status: 404 });
  if (!activeConversation) {
    const { data, error } = await supabase.from("conversations").insert({ user_id: user.id, dot_id: dot.id, title: message.slice(0, 64) }).select("id,title").single();
    if (error || !data) return Response.json({ error: "Could not create a conversation." }, { status: 500 });
    activeConversation = data;
  }

  const { data: savedUserMessage, error: userMessageError } = await supabase.from("messages").insert({ user_id: user.id, conversation_id: activeConversation.id, role: "user", content: message }).select("id").single();
  if (userMessageError || !savedUserMessage) return Response.json({ error: "Your message could not be saved." }, { status: 500 });

  const admin = createSupabaseAdminClient();
  await admin.from("dots").update({ status: "LISTENING", status_detail: "Receiving a message", last_active_at: new Date().toISOString() }).eq("id", dot.id).eq("user_id", user.id);
  await admin.from("activity_logs").insert({ user_id: user.id, dot_id: dot.id, event_type: "MESSAGE_RECEIVED", description: `Started a conversation with ${dot.name}.` });
  await admin.from("dots").update({ status: "THINKING", status_detail: "Considering your message" }).eq("id", dot.id).eq("user_id", user.id);

  const { data: history } = await supabase.from("messages").select("role,content").eq("user_id", user.id).eq("conversation_id", activeConversation.id).order("created_at", { ascending: false }).limit(20);
  const chatHistory = (history ?? []).reverse().map(({ role, content }) => ({ role: role as "user" | "assistant", content }));
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const isNova = dot.slug === "nova";
  const instructions = isNova
    ? `${dot.system_instructions}\n\nYou are Nova, a real career companion. Analyze the user's actual request and the recent conversation; do not use canned replies. When relevant, call get_career_context to consult the authenticated user's saved Nova goals and tasks. No skills profile or live internship-search provider is connected unless returned by a tool; never claim otherwise. Call create_career_goal or create_task only when the user explicitly asks you to save or track it. For recommendations, explain a concise rationale and realistic next steps. Do not reveal private chain-of-thought; provide conclusions and brief explanations only.`
    : dot.system_instructions;

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let responseText = "";
      let hasFailed = false;
      let respondingStateSet = false;
      const emit = (data: object) => controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
      const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

      try {
        emit({ activity: "Understanding your request..." });
        let modelInput: OpenAI.Responses.ResponseInput = chatHistory;

        const requestModel = async (input: OpenAI.Responses.ResponseInput) => {
          const modelStream = await openai.responses.create({
            model,
            instructions,
            input,
            tools: isNova ? novaTools : undefined,
            tool_choice: isNova ? "auto" : undefined,
            parallel_tool_calls: false,
            max_output_tokens: 900,
            stream: true,
            store: false,
          });

          let completedResponse: OpenAI.Responses.Response | null = null;
          for await (const event of modelStream) {
            if (event.type === "response.output_text.delta") {
              if (!respondingStateSet) {
                respondingStateSet = true;
                await admin.from("dots").update({ status: "RESPONDING", status_detail: "Writing a response" }).eq("id", dot.id).eq("user_id", user.id);
                emit({ activity: "Writing a response..." });
              }
              responseText += event.delta;
              emit({ delta: event.delta });
            } else if (event.type === "response.completed") {
              completedResponse = event.response;
            } else if (event.type === "response.failed" || event.type === "error") {
              throw new Error("The Responses API request failed.");
            }
          }

          if (!completedResponse) throw new Error("The Responses API did not complete the request.");
          return completedResponse;
        };

        let modelResponse = await requestModel(modelInput);
        let toolRound = 0;

        while (isNova) {
          const functionCalls = modelResponse.output.filter((item) => item.type === "function_call");
          if (functionCalls.length === 0) break;
          if (toolRound >= 3) throw new Error("Nova reached the tool-call limit for this response.");

          const toolOutputs: OpenAI.Responses.ResponseInputItem[] = [];
          for (const call of functionCalls) {
            const activity = call.name === "get_career_context"
              ? "Checking Nova's saved goals and tasks..."
              : call.name === "create_career_goal"
                ? "Saving the career goal you requested..."
                : "Saving the task you requested...";
            emit({ activity });
            await admin.from("dots").update({ status: "WORKING", status_detail: activity.replaceAll("...", "") }).eq("id", dot.id).eq("user_id", user.id);
            const result = await executeNovaTool(call.name, call.arguments, { admin, userId: user.id, dotId: dot.id, dotName: dot.name });
            toolOutputs.push({ type: "function_call_output", call_id: call.call_id, output: result.output });
          }

          modelInput = [...modelInput, ...modelResponse.output, ...toolOutputs];
          modelResponse = await requestModel(modelInput);
          toolRound += 1;
        }

        if (!responseText.trim()) throw new Error("The model returned an empty response.");

        const { data: savedMessage, error: saveError } = await admin.from("messages").insert({ user_id: user.id, conversation_id: activeConversation.id, role: "assistant", content: responseText }).select("id").single();
        if (saveError || !savedMessage) throw new Error("The response could not be saved.");
        await admin.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", activeConversation.id).eq("user_id", user.id);
        await admin.from("activity_logs").insert({ user_id: user.id, dot_id: dot.id, event_type: "RESPONSE_COMPLETED", description: `${dot.name} responded in conversation.` });
        await admin.from("dots").update({ status: "IDLE", status_detail: null, last_active_at: new Date().toISOString() }).eq("id", dot.id).eq("user_id", user.id);
        emit({ done: true, messageId: savedMessage.id, conversationId: activeConversation.id });
      } catch {
        hasFailed = true;
        await admin.from("dots").update({ status: "ERROR", status_detail: "The response could not be completed" }).eq("id", dot.id).eq("user_id", user.id);
        emit({ error: "Something went wrong while contacting the AI. Your message is saved; please try again." });
      } finally {
        if (hasFailed) await admin.from("activity_logs").insert({ user_id: user.id, dot_id: dot.id, event_type: "RESPONSE_FAILED", description: `${dot.name} could not complete a response.` });
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}