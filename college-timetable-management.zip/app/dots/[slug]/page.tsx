import { notFound, redirect } from "next/navigation";
import { DotWorkspace } from "@/components/dot-workspace";
import { SetupLanding } from "@/components/setup-landing";
import { orderDots, previewDots } from "@/lib/preview-dots";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { Dot, Task } from "@/types/dots";

export const dynamic = "force-dynamic";

export default async function DotPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!previewDots.some((dot) => dot.slug === slug)) notFound();

  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
    return <SetupLanding selectedDotSlug={slug} />;
  }

  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const [{ data: profile }, { data: dots, error: dotError }, { data: tasks }] = await Promise.all([
    supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle(),
    supabase.from("dots").select("id,user_id,name,slug,role,description,color,avatar_config,status,status_detail,last_active_at").eq("user_id", user.id).order("created_at"),
    supabase.from("tasks").select("id,title,description,status,priority,deadline").eq("user_id", user.id).not("status", "in", "(COMPLETED,CANCELLED)").order("deadline", { ascending: true, nullsFirst: false }).limit(12),
  ]);

  if (dotError) return <SetupLanding authAvailable message="Apply the database migration to activate your workspace." selectedDotSlug={slug} />;
  const ownedDots = orderDots((dots ?? []) as Dot[]);
  if (!ownedDots.some((dot) => dot.slug === slug)) notFound();

  return <DotWorkspace displayName={profile?.display_name ?? user.email?.split("@")[0] ?? "Friend"} userId={user.id} initialDots={ownedDots} initialTasks={(tasks ?? []) as Task[]} focusedDotSlug={slug} />;
}