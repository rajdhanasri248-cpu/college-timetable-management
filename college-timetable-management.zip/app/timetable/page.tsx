import type { Metadata } from "next";
import { TimetableDashboard } from "@/components/timetable-dashboard";

export const metadata: Metadata = {
  title: "Campus Timetable | Weekly Planner",
  description: "Manage your college class schedule week by week.",
};

export default function TimetablePage() {
  return <TimetableDashboard />;
}