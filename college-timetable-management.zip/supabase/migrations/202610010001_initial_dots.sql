create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Friend',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.dots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  slug text not null,
  role text not null,
  description text not null,
  color text not null,
  avatar_config jsonb not null default '{}'::jsonb,
  personality_config jsonb not null default '{}'::jsonb,
  system_instructions text not null,
  status text not null default 'IDLE' check (status in ('IDLE','LISTENING','THINKING','RESPONDING','WORKING','WAITING','COMPLETED','PAUSED','ERROR')),
  status_detail text,
  last_active_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, slug),
  unique (id, user_id)
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  dot_id uuid not null,
  title text not null default 'New conversation',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (dot_id, user_id) references public.dots(id, user_id) on delete cascade,
  unique (id, user_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  conversation_id uuid not null,
  role text not null check (role in ('user','assistant')),
  content text not null,
  created_at timestamptz not null default now(),
  foreign key (conversation_id, user_id) references public.conversations(id, user_id) on delete cascade
);

create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  dot_id uuid,
  title text not null,
  description text,
  status text not null default 'TODO' check (status in ('TODO','IN_PROGRESS','WAITING','COMPLETED','CANCELLED')),
  priority text not null default 'MEDIUM' check (priority in ('LOW','MEDIUM','HIGH')),
  deadline timestamptz,
  estimated_duration integer,
  actual_duration integer,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz,
  foreign key (dot_id, user_id) references public.dots(id, user_id) on delete set null (dot_id)
);

create table public.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  dot_id uuid,
  title text not null,
  description text,
  target_date date,
  progress integer not null default 0 check (progress between 0 and 100),
  status text not null default 'ACTIVE' check (status in ('ACTIVE','COMPLETED','PAUSED','ARCHIVED')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (dot_id, user_id) references public.dots(id, user_id) on delete set null (dot_id)
);

create table public.memories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  dot_id uuid,
  content text not null,
  memory_type text not null check (memory_type in ('PREFERENCE','FACT','GOAL','PROJECT_CONTEXT','CAREER_CONTEXT','STUDY_CONTEXT','PLANNING_PREFERENCE','USER_APPROVED_NOTE')),
  importance smallint not null default 3 check (importance between 1 and 5),
  sensitivity text not null default 'NORMAL' check (sensitivity in ('NORMAL','SENSITIVE')),
  consent_status text not null default 'PENDING' check (consent_status in ('PENDING','APPROVED','REJECTED')),
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (dot_id, user_id) references public.dots(id, user_id) on delete cascade
);

create table public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  dot_id uuid,
  event_type text not null,
  description text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  foreign key (dot_id, user_id) references public.dots(id, user_id) on delete cascade
);

create index dots_user_updated_idx on public.dots(user_id, updated_at desc);
create index conversations_user_dot_updated_idx on public.conversations(user_id, dot_id, updated_at desc);
create index messages_conversation_created_idx on public.messages(conversation_id, created_at desc);
create index tasks_user_status_deadline_idx on public.tasks(user_id, status, deadline);
create index goals_user_status_idx on public.goals(user_id, status);
create index memories_user_dot_consent_idx on public.memories(user_id, dot_id, consent_status);
create index activity_user_created_idx on public.activity_logs(user_id, created_at desc);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger dots_set_updated_at before update on public.dots for each row execute function public.set_updated_at();
create trigger conversations_set_updated_at before update on public.conversations for each row execute function public.set_updated_at();
create trigger tasks_set_updated_at before update on public.tasks for each row execute function public.set_updated_at();
create trigger goals_set_updated_at before update on public.goals for each row execute function public.set_updated_at();
create trigger memories_set_updated_at before update on public.memories for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  display_name text := coalesce(new.raw_user_meta_data ->> 'name', split_part(new.email, '@', 1), 'Friend');
begin
  insert into public.profiles (id, display_name) values (new.id, display_name);
  insert into public.dots (user_id, name, slug, role, description, color, avatar_config, personality_config, system_instructions)
  values
    (new.id, 'Mira', 'mira', 'Mental Wellbeing Agent', 'A calm space for reflection and gentle check-ins.', '#F18DB6', '{"body":"soft","accessory":"flower"}', '{"tone":"warm, calm, supportive, reflective"}', 'You are Mira, a warm wellbeing companion. Offer supportive reflection without diagnosing or claiming to be a clinician. Never claim mind-reading or encourage emotional dependency or isolation. Sensitive details are not automatically stored. If someone expresses immediate self-harm intent or danger, respond calmly, prioritize their immediate safety, and encourage contacting a trusted person and appropriate local emergency or crisis support.'),
    (new.id, 'Pixel', 'pixel', 'Coding Agent', 'A curious partner for code, DSA, and projects.', '#82C9A5', '{"body":"wide","accessory":"round-glasses"}', '{"tone":"technical, curious, precise, encouraging"}', 'You are Pixel, a precise and encouraging coding companion. Explain tradeoffs, ask for missing context when needed, and do not claim code was executed unless it was.'),
    (new.id, 'Nova', 'nova', 'Career & Internship Agent', 'Focused support for the work you want to do.', '#A58AE8', '{"body":"tall","accessory":"star"}', '{"tone":"focused, professional, organized"}', 'You are Nova, a focused career and internship companion. Be practical, honest about uncertainty, and never invent opportunities or external research.'),
    (new.id, 'Mint', 'mint', 'Personal Planning Agent', 'A practical companion for plans that can flex.', '#E9A477', '{"body":"pear","accessory":"leaf"}', '{"tone":"structured, calm, efficient, practical"}', 'You are Mint, a practical planning companion. Make realistic suggestions, clearly distinguish suggestions from actions, and do not claim calendar changes without integration authorization.');
  return new;
end;
$$;

create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.dots enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.tasks enable row level security;
alter table public.goals enable row level security;
alter table public.memories enable row level security;
alter table public.activity_logs enable row level security;

create policy "Users read own profile" on public.profiles for select using ((select auth.uid()) = id);
create policy "Users update own profile" on public.profiles for update using ((select auth.uid()) = id) with check ((select auth.uid()) = id);
create policy "Users read own dots" on public.dots for select using ((select auth.uid()) = user_id);
create policy "Users read own conversations" on public.conversations for select using ((select auth.uid()) = user_id);
create policy "Users create own conversations" on public.conversations for insert with check ((select auth.uid()) = user_id);
create policy "Users update own conversations" on public.conversations for update using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Users read own messages" on public.messages for select using ((select auth.uid()) = user_id);
create policy "Users create own messages" on public.messages for insert with check ((select auth.uid()) = user_id and role = 'user');
create policy "Users access own tasks" on public.tasks for all using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Users access own goals" on public.goals for all using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Users access own memories" on public.memories for all using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Users read own activity" on public.activity_logs for select using ((select auth.uid()) = user_id);

alter table public.dots replica identity full;
do $$ begin
  alter publication supabase_realtime add table public.dots;
exception when duplicate_object then null;
end $$;