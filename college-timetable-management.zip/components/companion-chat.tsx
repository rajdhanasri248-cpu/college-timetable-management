"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp, LoaderCircle, Plus, Sparkles } from "lucide-react";
import type { ChatMessage, Dot } from "@/types/dots";

const promptsByDot: Record<string, string[]> = {
  mira: ["Help me reflect on today", "I could use a small reset"],
  nova: ["Help me plan my next career step", "Review my internship goals"],
  pixel: ["Explain a concept I'm learning", "Help me reason through a bug"],
  mint: ["Help me make a plan for today", "What should I prioritize?"],
};

export function CompanionChat({ dot, onStateHint }: { dot: Dot; onStateHint?: (state: string) => void }) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [createNew, setCreateNew] = useState(false);
  const [draft, setDraft] = useState("");
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [sending, setSending] = useState(false);
  const [activity, setActivity] = useState("");
  const [error, setError] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const controller = new AbortController();
    setLoadingHistory(true);
    setMessages([]);
    setConversationId(null);
    setError("");

    fetch(`/api/dots/${dot.slug}/chat`, { signal: controller.signal })
      .then(async (response) => {
        if (!response.ok) throw new Error("Conversation history couldn't be loaded.");
        return response.json();
      })
      .then((data: { conversationId: string | null; messages: ChatMessage[] }) => {
        setConversationId(data.conversationId);
        setMessages(data.messages);
      })
      .catch((cause: unknown) => {
        if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "Conversation history couldn't be loaded.");
      })
      .finally(() => { if (!controller.signal.aborted) setLoadingHistory(false); });

    return () => controller.abort();
  }, [dot.slug]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  async function sendMessage(value = draft) {
    const message = value.trim();
    if (!message || sending) return;
    setDraft("");
    setSending(true);
    setActivity("");
    setError("");

    try {
      const response = await fetch(`/api/dots/${dot.slug}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, conversationId: conversationId ?? undefined, createNew }),
      });
      if (!response.ok) {
          const payload = await response.json().catch(() => ({})) as { error?: string; saved?: boolean; userMessageId?: string; conversationId?: string };
        if (payload.saved) {
          setMessages((current) => [...current, { id: payload.userMessageId ?? crypto.randomUUID(), role: "user", content: message }]);
          setConversationId(payload.conversationId ?? null);
          setCreateNew(false);
        }
        throw new Error(payload.error ?? "The message could not be sent.");
      }
      if (!response.body) throw new Error("The response stream was unavailable.");

      const userMessage: ChatMessage = { id: crypto.randomUUID(), role: "user", content: message };
      const responseId = crypto.randomUUID();
      setMessages((current) => [...current, userMessage, { id: responseId, role: "assistant", content: "" }]);
      onStateHint?.("THINKING");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let assistantText = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split("\n\n");
        buffer = events.pop() ?? "";
        for (const event of events) {
          const payloadLine = event.split("\n").find((line) => line.startsWith("data: "));
          if (!payloadLine) continue;
          const payload = JSON.parse(payloadLine.slice(6)) as { delta?: string; activity?: string; done?: boolean; error?: string; conversationId?: string; messageId?: string };
          if (payload.activity) setActivity(payload.activity);
          if (payload.delta) {
            assistantText += payload.delta;
            setMessages((current) => current.map((item) => item.id === responseId ? { ...item, content: assistantText } : item));
          }
          if (payload.done) {
            setMessages((current) => current.map((item) => item.id === responseId ? { ...item, id: payload.messageId ?? item.id } : item));
            setConversationId(payload.conversationId ?? null);
            setActivity("");
          }
          if (payload.error) throw new Error(payload.error);
        }
      }
      onStateHint?.("IDLE");
      setActivity("");
      setCreateNew(false);
    } catch (cause) {
      const errorMessage = cause instanceof Error ? cause.message : "The message could not be sent.";
      setError(errorMessage);
      setActivity("");
      setMessages((current) => current.filter((item) => item.content || item.role !== "assistant"));
      onStateHint?.("ERROR");
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void sendMessage();
    }
  }

  const prompts = promptsByDot[dot.slug] ?? promptsByDot.pixel;

  return (
    <section className="conversation-panel" aria-label={`${dot.name} conversation`}>
      <div className="conversation-heading"><div><span className="conversation-kicker">A PRIVATE SPACE WITH {dot.name.toUpperCase()}</span><strong>Talk it through.</strong></div><button className="conversation-new" onClick={() => { setMessages([]); setConversationId(null); setCreateNew(true); }} title="Start a fresh conversation"><Plus size={15} /></button></div>
      <div className="conversation-messages" ref={scrollRef} aria-live="polite">
        {loadingHistory ? <div className="message-skeletons"><i /><i /><i /></div> : messages.length === 0 ? <div className="conversation-empty"><span className="empty-spark"><Sparkles size={16} /></span><strong>Where would you like to begin?</strong><p>This conversation is private to you and {dot.name}.</p></div> : messages.map((message) => <div className={`chat-message chat-${message.role}`} key={message.id}><div className="message-avatar">{message.role === "assistant" ? <Sparkles size={12} /> : "D"}</div><div className="message-content">{message.content || <span className="streaming-caret" />}</div></div>)}
      </div>
      {sending && activity && <div className="agent-activity" role="status" aria-live="polite"><span className="activity-indicator"><i /></span><span className="agent-activity-name">{dot.name}</span><span>{activity}</span></div>}
      {!loadingHistory && messages.length === 0 && <div className="prompt-suggestions">{prompts.map((prompt) => <button key={prompt} disabled={sending} onClick={() => void sendMessage(prompt)}>{prompt}<ArrowUp size={12} /></button>)}</div>}
      {error && <p className="conversation-error" role="alert">{error}</p>}
      <form className="message-composer" onSubmit={(event) => { event.preventDefault(); void sendMessage(); }}>
        <textarea ref={inputRef} aria-label={`Message ${dot.name}`} value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={handleKeyDown} placeholder={`Tell ${dot.name} what's on your mind...`} rows={1} maxLength={4000} disabled={sending} />
        <div className="composer-footer"><span>Private to you and {dot.name} <span>·</span> Enter to send</span><button aria-label="Send message" disabled={sending || !draft.trim()}>{sending ? <LoaderCircle size={15} className="send-loading" /> : <ArrowUp size={16} />}</button></div>
      </form>
    </section>
  );
}