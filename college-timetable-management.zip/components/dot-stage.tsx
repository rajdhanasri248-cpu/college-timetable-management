"use client";

import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, Environment } from "@react-three/drei";
import { useReducedMotion } from "framer-motion";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import type { Dot, DotState } from "@/types/dots";

const shapeScale: Record<string, [number, number, number]> = {
  soft: [1, 1, 1],
  tall: [0.96, 1.04, 0.96],
  wide: [1.06, 0.96, 1],
  pear: [1, 0.98, 0.96],
};

type DotModelProps = {
  dot: Dot;
  active: boolean;
  position: [number, number, number];
  scale: number;
  onSelect: () => void;
  reducedMotion: boolean;
};

function DotModel({ dot, active, position, scale, onSelect, reducedMotion }: DotModelProps) {
  const body = useRef<THREE.Group>(null);
  const eyes = useRef<THREE.Group>(null);
  const bodyShape = dot.avatar_config?.body ?? "soft";
  const skinColor = dot.slug === "mint" ? "#fff2e4" : "#ffe1d7";
  const hairColor = dot.slug === "mira" ? "#754e44" : dot.slug === "pixel" ? "#72564d" : "#f6e5d2";
  const geometry = useMemo(() => {
    const sphere = new THREE.SphereGeometry(1, 64, 48);
    const positions = sphere.attributes.position;
    for (let index = 0; index < positions.count; index += 1) {
      let x = positions.getX(index);
      let y = positions.getY(index);
      let z = positions.getZ(index);

      if (bodyShape === "wide") {
        x *= 1.12;
        y *= 0.9;
        z *= 1.04;
      } else if (bodyShape === "tall") {
        const taper = 1 - y * 0.1;
        x *= 0.91 * taper;
        y *= 1.08;
        z *= 0.94 * taper;
      } else if (bodyShape === "pear") {
        const pear = 1 - y * 0.17;
        x *= pear;
        y *= 0.98;
        z *= pear;
      } else {
        x *= 1 + Math.sin(y * 3.2) * 0.035;
        z *= 1 + Math.cos(x * 3.5) * 0.025;
      }

      y = Math.max(y, -0.82);
      const ripple = 1 + 0.009 * Math.sin(x * 6 + y * 4) * Math.cos(z * 5 + y * 3);
      positions.setXYZ(index, x * ripple, y, z * ripple);
    }
    positions.needsUpdate = true;
    sphere.computeVertexNormals();
    return sphere;
  }, [bodyShape]);
  const fabricTexture = useMemo(() => {
    const size = 128;
    const data = new Uint8Array(size * size * 4);
    for (let y = 0; y < size; y += 1) {
      for (let x = 0; x < size; x += 1) {
        const index = (y * size + x) * 4;
        const grain = Math.abs(Math.sin(x * 127.1 + y * 311.7) * 43758.5453) % 1;
        const value = 118 + Math.round(grain * 137);
        data[index] = value;
        data[index + 1] = value;
        data[index + 2] = value;
        data[index + 3] = 255;
      }
    }
    const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(2, 2);
    texture.needsUpdate = true;
    return texture;
  }, []);

  const state: DotState = dot.status ?? "IDLE";
  const movement = state === "WORKING" ? 2.3 : state === "THINKING" ? 0.45 : state === "WAITING" || state === "ERROR" || state === "PAUSED" ? 0.12 : 1;
  const bodyScale = shapeScale[dot.avatar_config?.body ?? "soft"] ?? shapeScale.soft;

  useFrame(({ clock }) => {
    if (!body.current || reducedMotion) return;
    const time = clock.getElapsedTime();
    const breath = Math.sin(time * movement + position[0]) * (active ? 0.025 : 0.018);
    const completionBounce = state === "COMPLETED" ? Math.max(0, Math.sin(time * 3.2)) * 0.045 : 0;
    body.current.scale.set(scale * bodyScale[0], scale * bodyScale[1] * (1 + breath + completionBounce), scale * bodyScale[2]);
    body.current.position.y = position[1] + Math.sin(time * movement + position[0]) * (active ? 0.018 : 0.012) + completionBounce;
    body.current.rotation.z = state === "ERROR" ? -0.035 : Math.sin(time * movement * 0.62 + position[0]) * (active ? 0.035 : 0.018);
    body.current.rotation.y = Math.sin(time * 0.32 + position[0] * 2) * 0.055;

    if (eyes.current && state === "LISTENING") {
      body.current.rotation.x = -0.055;
    } else if (body.current) {
      body.current.rotation.x = Math.sin(time * 0.42 + position[0]) * 0.012;
    }

    if (eyes.current) {
      const blink = (time + position[0] * 1.7) % 6.4 > 6.18 ? 0.12 : 1;
      eyes.current.scale.y = blink;
    }
  });

  return (
    <group ref={body} position={position} onClick={(event) => { event.stopPropagation(); onSelect(); }}>
      <mesh geometry={geometry} position={[0, -0.54, 0]} scale={[0.58, 0.56, 0.49]} castShadow receiveShadow>
        <meshPhysicalMaterial color={dot.slug === "mint" ? "#f7eee8" : dot.color} roughness={0.78} bumpMap={fabricTexture} bumpScale={0.035} metalness={0} clearcoat={0.08} clearcoatRoughness={0.86} sheen={0.78} sheenRoughness={0.9} />
      </mesh>
      <mesh position={[0, 0.15, 0]} scale={[0.66, 0.65, 0.56]} castShadow receiveShadow>
        <sphereGeometry args={[1, 48, 40]} />
        <meshPhysicalMaterial color={skinColor} roughness={0.67} bumpMap={fabricTexture} bumpScale={0.018} clearcoat={0.14} clearcoatRoughness={0.74} sheen={0.38} sheenRoughness={0.86} />
      </mesh>
      <mesh position={[0, -0.24, 0.36]} scale={[0.37, 0.14, 0.24]}>
        <sphereGeometry args={[1, 32, 24]} />
        <meshPhysicalMaterial color={dot.color} roughness={0.76} bumpMap={fabricTexture} bumpScale={0.03} sheen={0.7} />
      </mesh>
      {[-1, 1].map((side) => <mesh key={side} position={[side * 0.55, -0.39, 0.12]} rotation={[0.1, 0, side * 0.48]} scale={[0.24, 0.16, 0.2]} castShadow>
        <sphereGeometry args={[1, 28, 22]} />
        <meshPhysicalMaterial color={dot.color} roughness={0.76} bumpMap={fabricTexture} bumpScale={0.025} sheen={0.72} />
      </mesh>)}
      {[-1, 1].map((side) => <mesh key={side} position={[side * 0.22, -0.94, 0.12]} rotation={[0, 0, side * 0.12]} scale={[0.22, 0.11, 0.2]} castShadow>
        <sphereGeometry args={[1, 24, 18]} />
        <meshPhysicalMaterial color={dot.slug === "mint" ? "#f4e9df" : dot.color} roughness={0.8} bumpMap={fabricTexture} bumpScale={0.02} sheen={0.7} />
      </mesh>)}
      {dot.slug === "mira" && <group>
        <mesh position={[0, 0.53, -0.08]} scale={[0.62, 0.36, 0.52]}><sphereGeometry args={[1, 32, 24]} /><meshPhysicalMaterial color="#70493f" roughness={0.75} bumpMap={fabricTexture} bumpScale={0.025} sheen={0.55} /></mesh>
        <mesh position={[0, 0.57, 0.17]} scale={[0.55, 0.25, 0.48]}><sphereGeometry args={[1, 32, 24]} /><meshPhysicalMaterial color="#80584c" roughness={0.77} bumpMap={fabricTexture} bumpScale={0.02} sheen={0.5} /></mesh>
        {[-1, -0.35, 0.35, 1].map((lock) => <mesh key={lock} position={[lock * 0.22, 0.39 - Math.abs(lock) * 0.055, 0.43 - Math.abs(lock) * 0.07]} rotation={[0, 0, lock * -0.16]} scale={[0.18, 0.2, 0.14]}><sphereGeometry args={[1, 24, 18]} /><meshPhysicalMaterial color={lock < 0 ? "#70493f" : "#8e6455"} roughness={0.75} bumpMap={fabricTexture} bumpScale={0.018} /></mesh>)}
        {[[0.53, 0.38, 0.4], [0.62, 0.18, 0.34], [0.63, -0.04, 0.3], [0.58, -0.25, 0.24], [0.46, -0.4, 0.17]].map(([x, y, z], index) => <mesh key={index} position={[x, y, z]} scale={[0.15, 0.16, 0.13]}><sphereGeometry args={[1, 24, 18]} /><meshPhysicalMaterial color={index % 2 ? "#96695a" : "#805548"} roughness={0.74} bumpMap={fabricTexture} bumpScale={0.02} sheen={0.54} /></mesh>)}
      </group>}
      {dot.slug === "pixel" && <group>
        <mesh position={[0, 0.48, -0.08]} scale={[0.61, 0.4, 0.5]}><sphereGeometry args={[1, 32, 24]} /><meshPhysicalMaterial color="#72564d" roughness={0.75} bumpMap={fabricTexture} bumpScale={0.025} /></mesh>
        {[-1, 1].map((side) => <mesh key={side} position={[side * 0.49, 0.12, 0.22]} scale={[0.18, 0.29, 0.19]}><sphereGeometry args={[1, 24, 18]} /><meshPhysicalMaterial color="#8b6758" roughness={0.76} bumpMap={fabricTexture} bumpScale={0.02} /></mesh>)}
        <mesh position={[0, 0.72, 0.02]} scale={[0.58, 0.27, 0.52]}><sphereGeometry args={[1, 32, 24]} /><meshPhysicalMaterial color="#b9a3e9" roughness={0.75} bumpMap={fabricTexture} bumpScale={0.025} sheen={0.72} /></mesh>
        <mesh position={[0, 0.57, 0.22]} scale={[0.57, 0.09, 0.46]}><sphereGeometry args={[1, 32, 20]} /><meshPhysicalMaterial color="#a58bdc" roughness={0.78} bumpMap={fabricTexture} bumpScale={0.025} /></mesh>
        <mesh position={[0.42, 0.58, 0.12]} scale={[0.13, 0.13, 0.1]}><sphereGeometry args={[1, 20, 16]} /><meshPhysicalMaterial color="#e7c0db" roughness={0.72} /></mesh>
      </group>}
      {dot.slug === "mira" && <group>
        {[-1, 1].map((side) => [0.3, 0.1, -0.1, -0.3].map((height, index) => <mesh key={`${side}-${index}`} position={[side * (0.53 + (index % 2) * 0.03), height, 0.06]} rotation={[0, 0, side * 0.18]} scale={[0.14, 0.16, 0.13]}><sphereGeometry args={[1, 24, 18]} /><meshPhysicalMaterial color={index % 2 ? "#765044" : "#886052"} roughness={0.75} bumpMap={fabricTexture} bumpScale={0.02} /></mesh>))}
      </group>}
      {dot.slug === "nova" && <group>
        {[[0, 0.71, -0.03, 0.34], [-0.39, 0.65, 0.06, 0.25], [0.39, 0.65, 0.06, 0.25], [-0.2, 0.9, -0.02, 0.24], [0.2, 0.9, -0.02, 0.24], [-0.51, 0.43, 0.05, 0.19], [0.51, 0.43, 0.05, 0.19]].map(([x, y, z, radius], index) => <mesh key={index} position={[x, y, z]} scale={[radius, radius, radius * 0.9]}><sphereGeometry args={[1, 24, 18]} /><meshPhysicalMaterial color={index % 2 ? "#fff0e1" : "#f6decf"} roughness={0.82} bumpMap={fabricTexture} bumpScale={0.025} sheen={0.66} /></mesh>)}
        <mesh position={[0, -0.38, 0.24]} rotation={[0, 0, 0.02]} scale={[0.84, 0.055, 0.045]}><sphereGeometry args={[1, 28, 18]} /><meshPhysicalMaterial color="#ee7fa0" roughness={0.68} sheen={0.74} /></mesh>
        <mesh position={[-0.68, -0.52, 0.28]} rotation={[0, 0, -0.3]} scale={[0.31, 0.045, 0.04]}><sphereGeometry args={[1, 24, 16]} /><meshPhysicalMaterial color="#f197ac" roughness={0.66} sheen={0.76} /></mesh>
        <mesh position={[0.68, -0.52, 0.28]} rotation={[0, 0, 0.3]} scale={[0.31, 0.045, 0.04]}><sphereGeometry args={[1, 24, 16]} /><meshPhysicalMaterial color="#f197ac" roughness={0.66} sheen={0.76} /></mesh>
      </group>}
      {dot.slug === "mint" && <group>
        <mesh position={[0, -0.34, 0.37]} scale={[0.23, 0.12, 0.1]}><torusGeometry args={[1, 0.28, 12, 32]} /><meshPhysicalMaterial color="#eaa477" roughness={0.68} sheen={0.62} /></mesh>
        {[-0.52, -0.68, -0.84].map((height) => <mesh key={height} position={[0, height, 0.4]} scale={0.043}><sphereGeometry args={[1, 16, 12]} /><meshPhysicalMaterial color="#77564e" roughness={0.42} clearcoat={0.35} /></mesh>)}
        <mesh position={[0.2, 0.92, 0.02]} rotation={[0, 0, -0.5]} scale={[0.1, 0.22, 0.1]}><capsuleGeometry args={[0.5, 1, 5, 12]} /><meshPhysicalMaterial color="#e7a779" roughness={0.7} /></mesh>
        <mesh position={[0.29, 1.05, 0.02]} scale={0.09}><sphereGeometry args={[1, 20, 16]} /><meshPhysicalMaterial color="#efb9a7" roughness={0.68} /></mesh>
      </group>}
      <group ref={eyes} position={[0, 0.14, 0.69]}>
        <mesh position={[-0.2, 0, 0]} scale={[0.09, 0.105, 0.05]}><sphereGeometry args={[1, 24, 20]} /><meshPhysicalMaterial color="#171519" roughness={0.28} clearcoat={0.65} /></mesh>
        <mesh position={[0.2, 0, 0]} scale={[0.09, 0.105, 0.05]}><sphereGeometry args={[1, 24, 20]} /><meshPhysicalMaterial color="#171519" roughness={0.28} clearcoat={0.65} /></mesh>
        <mesh position={[-0.221, 0.04, 0.046]} scale={0.021}><sphereGeometry args={[1, 12, 10]} /><meshBasicMaterial color="#fff8f2" /></mesh>
        <mesh position={[0.179, 0.04, 0.046]} scale={0.021}><sphereGeometry args={[1, 12, 10]} /><meshBasicMaterial color="#fff8f2" /></mesh>
        {dot.avatar_config?.accessory === "round-glasses" && <group position={[0, 0.005, 0.028]}>
          <mesh position={[-0.2, 0, -0.018]}><circleGeometry args={[0.132, 40]} /><meshPhysicalMaterial color="#d8f0da" transparent opacity={0.2} roughness={0.18} side={THREE.DoubleSide} /></mesh>
          <mesh position={[0.2, 0, -0.018]}><circleGeometry args={[0.132, 40]} /><meshPhysicalMaterial color="#d8f0da" transparent opacity={0.2} roughness={0.18} side={THREE.DoubleSide} /></mesh>
          <mesh position={[-0.2, 0, 0]}><torusGeometry args={[0.16, 0.027, 12, 40]} /><meshStandardMaterial color="#3c3939" roughness={0.58} /></mesh>
          <mesh position={[0.2, 0, 0]}><torusGeometry args={[0.16, 0.027, 12, 40]} /><meshStandardMaterial color="#3c3939" roughness={0.58} /></mesh>
          <mesh position={[0, 0, 0]}><boxGeometry args={[0.1, 0.03, 0.025]} /><meshStandardMaterial color="#3c3939" roughness={0.58} /></mesh>
        </group>}
      </group>
      <group position={[0, 0.01, 0.72]}>
        <mesh position={[-0.36, 0, 0]} scale={[0.12, 0.075, 0.025]}><sphereGeometry args={[1, 20, 14]} /><meshBasicMaterial color="#f39aa0" transparent opacity={0.52} /></mesh>
        <mesh position={[0.36, 0, 0]} scale={[0.12, 0.075, 0.025]}><sphereGeometry args={[1, 20, 14]} /><meshBasicMaterial color="#f39aa0" transparent opacity={0.52} /></mesh>
      </group>
      <mesh position={[0, -0.13, 0.73]} scale={[0.045, 0.038, 0.024]}><sphereGeometry args={[1, 20, 14]} /><meshPhysicalMaterial color="#a86165" roughness={0.48} /></mesh>
      {dot.avatar_config?.accessory === "flower" && <group position={[-0.32, 0.55, 0.9]} rotation={[0.2, 0.25, -0.2]}>
        {[0, 1, 2, 3, 4].map((petal) => <mesh key={petal} position={[Math.cos(petal * 1.256) * 0.085, Math.sin(petal * 1.256) * 0.085, 0]} scale={[0.095, 0.12, 0.055]} rotation={[0, 0, petal * 1.256]}><sphereGeometry args={[1, 20, 16]} /><meshPhysicalMaterial color="#ffd8e7" roughness={0.78} sheen={0.76} /></mesh>)}
        <mesh position={[0, 0, 0.06]} scale={0.055}><sphereGeometry args={[1, 16, 12]} /><meshPhysicalMaterial color="#f3c878" roughness={0.66} /></mesh>
      </group>}
      {dot.avatar_config?.accessory === "leaf" && <group position={[0.18, 0.7, 0.67]} rotation={[0.3, 0.15, 0.65]}>
        <mesh scale={[0.12, 0.24, 0.055]}><sphereGeometry args={[1, 28, 20]} /><meshPhysicalMaterial color="#7dab67" roughness={0.84} sheen={0.48} /></mesh>
        <mesh position={[0, 0, 0.055]} scale={[0.012, 0.15, 0.008]}><boxGeometry args={[1, 1, 1]} /><meshStandardMaterial color="#b1c992" roughness={0.8} /></mesh>
        <mesh position={[-0.13, 0.04, -0.035]} scale={[0.09, 0.16, 0.05]} rotation={[0, 0, -0.62]}><sphereGeometry args={[1, 20, 14]} /><meshPhysicalMaterial color="#9fbd7e" roughness={0.86} /></mesh>
      </group>}
      {active && <mesh position={[0, -0.47, 0.51]} scale={[0.48, 0.035, 0.015]}><sphereGeometry args={[1, 24, 12]} /><meshBasicMaterial color="#372b31" transparent opacity={0.35} /></mesh>}
    </group>
  );
}

export function DotStage({ dots, activeId, onSelect, preview = false }: { dots: Dot[]; activeId?: string; onSelect: (dot: Dot) => void; preview?: boolean }) {
  const reducedMotion = useReducedMotion() ?? false;
  if (!dots.length) return <div className="dot-stage-empty" aria-label="No companions yet" />;

  const selected = Math.max(0, dots.findIndex((dot) => dot.id === activeId));
  const positions = dots.map((_, index): [number, number, number] => {
    if (preview) return [0, ((dots.length - 1) / 2 - index) * 1.5, 0];
    if (index === selected) return [0, -0.34, 0];
    const side = index < selected ? -1 : 1;
    const offset = Math.abs(index - selected);
    return [side * (1.28 + offset * 0.72), -0.62 + Math.min(offset, 2) * 0.09, -0.6 - offset * 0.22];
  });

  return (
    <div className={`dot-stage ${preview ? "dot-stage-preview" : ""}`}>
      <Canvas dpr={[1, 1.5]} camera={{ position: [0, 0.14, preview ? 14.5 : 6], fov: 33 }} shadows gl={{ alpha: true, antialias: true }}>
        <ambientLight intensity={1.3} />
        <hemisphereLight args={["#fff4ed", "#52464f", 1.15]} />
        <directionalLight position={[-3.2, 4.5, 5]} intensity={3} color="#fff1e2" castShadow shadow-mapSize={[1024, 1024]} />
        <pointLight position={[3.4, 1.4, -1]} intensity={18} color="#efb5ce" distance={9} />
        <pointLight position={[-4, 0.8, -2]} intensity={14} color="#a9b9f1" distance={9} />
        <Environment preset="apartment" environmentIntensity={0.45} />
        {dots.map((dot, index) => <DotModel key={dot.id} dot={dot} active={dot.id === activeId} position={positions[index]} scale={preview ? 0.9 : dot.id === activeId ? 0.93 : 0.49} onSelect={() => onSelect(dot)} reducedMotion={reducedMotion} />)}
        <ContactShadows position={[0, -1.23, 0]} opacity={0.3} scale={8} blur={2.8} far={2.5} color="#211c28" />
      </Canvas>
      <div className="stage-floor-glow" />
    </div>
  );
}