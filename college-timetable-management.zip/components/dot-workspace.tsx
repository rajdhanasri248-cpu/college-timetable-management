"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowUpRight,
  AudioLines,
  BookHeart,
  CalendarDays,
  Check,
  ChevronRight,
  CircleHelp,
  Compass,
  Flame,
  FolderOpen,
  Goal,
  Home,
  LayoutGrid,
  LogOut,
  Plus,
  Settings2,
  Sparkles,
  SquareCheckBig,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CompanionChat } from "@/components/companion-chat";
import { DotStage } from "@/components/dot-stage";
import { SetupLanding } from "@/components/setup-landing";
import { orderDots } from "@/lib/preview-dots";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";
import type { Dot, Task } from "@/types/dots";

const stateLabels: Record<string, string> = {
  IDLE: "At ease",
  LISTENING: "Listening",
  THINKING: "Thinking",
  RESPONDING: "Responding",
  WORKING: "Working",
  WAITING: "Waiting for you",
  COMPLETED: "Finished",
  PAUSED: "Paused",
  ERROR: "Needs a moment",
};

const navigation = [
  { label: "Home", icon: Home, active: true },
  { label: "My Dots", icon: LayoutGrid },
  { label: "Tasks", icon: SquareCheckBig },
  { label: "Goals", icon: Goal },
  { label: "Journal", icon: BookHeart },
  { label: "Calendar", icon: CalendarDays },
  { label: "Files", icon: FolderOpen },
];

export function DotWorkspace({ displayName, userId, initialDots, initialTasks, focusedDotSlug }: { displayName: string; userId: string; initialDots: Dot[]; initialTasks: Task[]; focusedDotSlug?: string }) {
  const router = useRouter();
  const [dots, setDots] = useState(initialDots);
  const [tasks, setTasks] = useState(initialTasks);
  const [selectedDotId, setSelectedDotId] = useState(initialDots.find((dot) => dot.slug === focusedDotSlug)?.id ?? initialDots[0]?.id ?? "");
  const [taskDraft, setTaskDraft] = useState("");
  const [addingTask, setAddingTask] = useState(false);
  const [notice, setNotice] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const selectedDot = dots.find((dot) => dot.id === selectedDotId) ?? dots[0];
  const isDotWorkspace = Boolean(focusedDotSlug);

  useEffect(() => {
    if (focusedDotSlug) {
      const focusedDot = dots.find((dot) => dot.slug === focusedDotSlug);
      if (focusedDot) setSelectedDotId(focusedDot.id);
    }
  }, [dots, focusedDotSlug]);

  useEffect(() => {
    const supabase = createSupabaseBrowserClient();
    const refreshDots = async () => {
      const { data } = await supabase.from("dots").select("id,user_id,name,slug,role,description,color,avatar_config,status,status_detail,last_active_at").eq("user_id", userId).order("created_at");
      if (data) setDots(orderDots(data as Dot[]));
    };

    const channel = supabase.channel(`dots:${userId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "dots", filter: `user_id=eq.${userId}` }, (payload) => {
        if (payload.eventType === "DELETE") setDots((current) => current.filter((dot) => dot.id !== (payload.old as Dot).id));
        else {
          const updated = payload.new as Dot;
          setDots((current) => orderDots(current.some((dot) => dot.id === updated.id) ? current.map((dot) => dot.id === updated.id ? updated : dot) : [...current, updated]));
        }
      })
      .subscribe((status) => { if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") void refreshDots(); });

    return () => { void supabase.removeChannel(channel); };
  }, [userId]);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(""), 3200);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  async function signOut() {
    const supabase = createSupabaseBrowserClient();
    await supabase.auth.signOut();
    window.location.assign("/login");
  }

  function openDot(dot: Dot) {
    setMobileNavOpen(false);
    router.push(`/dots/${dot.slug}`);
  }

  async function addTask(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const title = taskDraft.trim();
    if (!title || addingTask) return;
    setAddingTask(true);
    const supabase = createSupabaseBrowserClient();
    const { data, error } = await supabase.from("tasks").insert({ user_id: userId, dot_id: selectedDot?.id ?? null, title }).select("id,title,description,status,priority,deadline").single();
    if (error || !data) setNotice("That task couldn't be saved. Please try again.");
    else {
      setTasks((current) => [...current, data as Task]);
      setTaskDraft("");
      setNotice("Task saved.");
    }
    setAddingTask(false);
  }

  async function completeTask(task: Task) {
    const supabase = createSupabaseBrowserClient();
    const { error } = await supabase.from("tasks").update({ status: "COMPLETED", completed_at: new Date().toISOString() }).eq("id", task.id).eq("user_id", userId);
    if (error) setNotice("Task completion wasn't saved. Please retry.");
    else {
      setTasks((current) => current.filter((item) => item.id !== task.id));
      setNotice("Task complete.");
    }
  }

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "A fresh start, whenever you are." : hour < 18 ? "Take the day at your pace." : "A little room to land.";
  const firstName = displayName.trim().split(/\s+/)[0] || "Friend";

  if (!selectedDot) return <SetupLanding message="Your account is ready, but no Dot records were found. Reapply the signup migration and refresh." />;

  return (
    <div className="dot-app-shell">
      <aside className={`dot-sidebar ${mobileNavOpen ? "dot-sidebar-open" : ""}`}>
        <Link href="/" className="dots-wordmark"><span className="wordmark-glyph"><Sparkles size={15} /></span>DOTS</Link>
        <button className="space-switch"><span className="space-avatar">{firstName.slice(0, 1).toUpperCase()}</span><span><strong>{firstName}&apos;s space</strong><small>Personal room</small></span><span className="space-caret">⌄</span></button>
        <span className="sidebar-heading">YOUR SPACE</span>
        <nav className="room-nav" aria-label="Workspace navigation">
          {navigation.map(({ label, icon: Icon, active }) => <a key={label} href={label === "Home" ? isDotWorkspace ? "/" : "#home" : label === "Tasks" ? "#focus" : label === "My Dots" ? isDotWorkspace ? "/#my-dots" : "#my-dots" : "#coming-next"} className={`room-nav-link ${active && !isDotWorkspace ? "room-nav-active" : ""}`} onClick={() => setMobileNavOpen(false)}><Icon size={16} strokeWidth={1.8} /><span>{label}</span>{label === "Tasks" && tasks.length > 0 && <i>{tasks.length}</i>}</a>)}
        </nav>
        <span className="sidebar-heading sidebar-dots-heading">COMPANIONS <button onClick={() => setNotice("Custom Dot creation is coming in a later phase.")} aria-label="Add a Dot"><Plus size={13} /></button></span>
        <div className="sidebar-dot-list">{dots.map((dot) => <button key={dot.id} className={`sidebar-dot ${dot.id === selectedDot.id ? "sidebar-dot-active" : ""}`} onClick={() => openDot(dot)}><span className="sidebar-dot-color" style={{ background: dot.color }} /><span className="sidebar-dot-copy"><strong>{dot.name}</strong><small>{stateLabels[dot.status ?? ""] ?? "Status unavailable"}</small></span><i className={`state-led state-led-${(dot.status ?? "unknown").toLowerCase()}`} /></button>)}</div>
        <div className="sidebar-bottom"><a href="#coming-next" className="room-nav-link"><Settings2 size={16} /><span>Settings</span></a><button className="signout-button" onClick={() => void signOut()}><LogOut size={16} /><span>Sign out</span></button><div className="privacy-note"><ShieldIcon /><span>Your space is yours.<br />Always.</span></div></div>
      </aside>
      {mobileNavOpen && <button className="mobile-nav-scrim" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)} />}

      <div className="dot-main-column" id="home">
        <header className="room-topbar"><button className="mobile-nav-toggle" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation"><Compass size={19} /></button><span className="topbar-path">Your space <i>/</i> <strong>{isDotWorkspace ? selectedDot.name : "Home"}</strong></span><div className="topbar-right"><div className="streak-pill"><Flame size={15} /><span>YOUR PACE</span></div><button className="profile-button" aria-label="Sign out" onClick={() => void signOut()}>{firstName.slice(0, 1).toUpperCase()}</button></div></header>

        <main className="room-content">
          <div className="room-intro"><div>{isDotWorkspace && <Link href="/" className="dot-back-link"><ArrowLeft size={13} /> MY DOTS</Link>}<span className="room-date">{isDotWorkspace ? `${selectedDot.name.toUpperCase()} / YOUR COMPANION SPACE` : new Intl.DateTimeFormat("en", { weekday: "long", month: "long", day: "numeric" }).format(new Date()).toUpperCase()}</span><h1>{isDotWorkspace ? <>Inside {selectedDot.name}<span>.</span></> : <>Welcome in, {firstName}<span>.</span></>}</h1><p>{isDotWorkspace ? selectedDot.description : greeting}</p></div><div className="room-weather-mark"><span className="weather-star">✳</span><span>{isDotWorkspace ? selectedDot.role.toUpperCase() : "YOUR WORLD, AT YOUR PACE"}</span></div></div>

          <div className="room-grid">
            <div className="room-primary">
              <section className="companion-room" aria-label={`${selectedDot.name} companion space`}>
                <div className="room-orbit-label"><span>WITH YOU, NOT IN THE WAY</span><span className="orbit-counter">{String(dots.findIndex((dot) => dot.id === selectedDot.id) + 1).padStart(2, "0")} <i>/</i> {String(dots.length).padStart(2, "0")}</span></div>
                <DotStage dots={dots} activeId={selectedDot.id} onSelect={openDot} />
                <AnimatePresence mode="wait"><motion.div key={selectedDot.id} className="selected-dot-info" initial={{ opacity: 0, y: 7 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} transition={{ duration: 0.18 }}>
                  <div className="selected-dot-kicker"><span className="selected-dot-color" style={{ backgroundColor: selectedDot.color }} />{selectedDot.role}</div>
                  <h2>{selectedDot.name}<span>.</span></h2>
                  <div className={`live-state live-state-${(selectedDot.status ?? "unknown").toLowerCase()}`}><i />{stateLabels[selectedDot.status ?? ""] ?? "Status unavailable"}{selectedDot.status_detail && <span>· {selectedDot.status_detail}</span>}</div>
                  <p>{selectedDot.description}</p>
                </motion.div></AnimatePresence>
                <div className="companion-selector" id="my-dots" aria-label="Open a companion workspace">{dots.map((dot) => <button key={dot.id} className={`companion-select ${dot.id === selectedDot.id ? "companion-select-active" : ""}`} onClick={() => openDot(dot)} aria-label={`Open ${dot.name} workspace`}><span className="select-dot" style={{ background: dot.color }} /><span>{dot.name}</span><i className={`state-led state-led-${(dot.status ?? "unknown").toLowerCase()}`} /></button>)}</div>
              </section>
              <CompanionChat key={selectedDot.id} dot={selectedDot} />
            </div>

            <aside className="room-aside">
              <section className="focus-shelf" id="focus">
                <div className="shelf-heading"><div><span className="eyebrow">TODAY, IF IT HELPS</span><h2>A few things in reach</h2></div><span className="task-count">{tasks.length.toString().padStart(2, "0")}</span></div>
                <div className="focus-task-list">{tasks.map((task) => <div className="focus-task" key={task.id}><button className="task-complete" onClick={() => void completeTask(task)} aria-label={`Complete ${task.title}`}><Check size={12} /></button><div className="focus-task-copy"><strong>{task.title}</strong><span>{task.deadline ? `Due ${new Intl.DateTimeFormat("en", { month: "short", day: "numeric" }).format(new Date(task.deadline))}` : task.priority === "HIGH" ? "High priority" : "When you're ready"}</span></div><span className={`priority-mark priority-${task.priority.toLowerCase()}`} title={`${task.priority.toLowerCase()} priority`} /></div>)}{tasks.length === 0 && <div className="task-empty"><SquareCheckBig size={17} /><span>No tasks pulling at you.<br />That&apos;s a nice place to start.</span></div>}</div>
                <form className="quick-task-form" onSubmit={(event) => void addTask(event)}><Plus size={14} /><input aria-label="Add a task" value={taskDraft} onChange={(event) => setTaskDraft(event.target.value)} placeholder="Add one small thing..." maxLength={160} /><button disabled={!taskDraft.trim() || addingTask} aria-label="Save task"><ArrowUpRight size={13} /></button></form>
                <a className="shelf-link" href="#focus">Your task list <ChevronRight size={14} /></a>
              </section>

              <section className="room-note" id="coming-next"><div className="note-top"><span className="eyebrow">A LITTLE SPACE TO THINK</span><BookHeart size={15} /></div><p>Some days, showing up is the whole thing.</p><span className="note-author">A NOTE FOR TODAY <i>·</i> PRIVATE TO YOU</span></section>

              <section className="coming-shelf"><div className="coming-shelf-heading"><span className="eyebrow">GROWING WITH YOU</span><CircleHelp size={14} /></div><div className="coming-row"><span><Goal size={15} /></span><div><strong>Goals & milestones</strong><small>Your longer arcs, in view</small></div><span className="coming-soon">NEXT</span></div><div className="coming-row"><span><AudioLines size={15} /></span><div><strong>Journal & reflection</strong><small>A record only you can see</small></div><span className="coming-soon">NEXT</span></div><div className="coming-row"><span><CalendarDays size={15} /></span><div><strong>Flexible daily plans</strong><small>Make a plan that can bend</small></div><span className="coming-soon">NEXT</span></div></section>

              <div className="privacy-foot"><Sparkles size={12} /><span>Conversations are private to your account.</span><button aria-label="Learn about privacy" onClick={() => setNotice("Messages are protected by per-user database policies.")}><ArrowUpRight size={12} /></button></div>
            </aside>
          </div>
        </main>
        <nav className="mobile-bottom-nav" aria-label="Mobile navigation"><a href="#home" className="mobile-nav-active"><Home size={18} /><span>Home</span></a><a href="#my-dots"><LayoutGrid size={18} /><span>Dots</span></a><a href="#focus"><SquareCheckBig size={18} /><span>Tasks</span></a><a href="#coming-next"><BookHeart size={18} /><span>Journal</span></a><button onClick={() => void signOut()}><LogOut size={18} /><span>Profile</span></button></nav>
      </div>
      <AnimatePresence>{notice && <motion.div className="room-toast" role="status" initial={{ opacity: 0, y: 9 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 7 }}>{notice}</motion.div>}</AnimatePresence>
    </div>
  );
}

function ShieldIcon() {
  return <span className="privacy-shield"><Sparkles size={12} /></span>;
}