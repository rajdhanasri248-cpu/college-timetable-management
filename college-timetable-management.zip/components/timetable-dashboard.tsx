"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  BookOpen,
  CalendarDays,
  CalendarPlus,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Download,
  GraduationCap,
  MapPin,
  Plus,
  Search,
  Trash2,
  UserRound,
  X,
} from "lucide-react";
import styles from "./timetable-dashboard.module.css";

type Weekday = "Mon" | "Tue" | "Wed" | "Thu" | "Fri";
type TimetableClass = {
  id: string;
  subject: string;
  code: string;
  instructor: string;
  room: string;
  day: Weekday;
  start: string;
  end: string;
  color: string;
};

const weekdays: Weekday[] = ["Mon", "Tue", "Wed", "Thu", "Fri"];
const baseMonday = new Date(2026, 9, 12);
const todayDate = new Date(2026, 9, 14);
const millisecondsPerWeek = 7 * 24 * 60 * 60 * 1000;
const initialClasses: TimetableClass[] = [
  { id: "c1", subject: "Data Structures", code: "CS 204", instructor: "Dr. Mira Shah", room: "Block C · 204", day: "Mon", start: "09:00", end: "10:30", color: "mint" },
  { id: "c2", subject: "Linear Algebra", code: "MA 201", instructor: "Prof. A. Nair", room: "Block A · 112", day: "Mon", start: "11:00", end: "12:00", color: "lilac" },
  { id: "c3", subject: "Digital Systems", code: "EC 215", instructor: "Dr. K. Menon", room: "Lab 3 · Block D", day: "Mon", start: "14:00", end: "16:00", color: "peach" },
  { id: "c4", subject: "Operating Systems", code: "CS 302", instructor: "Prof. R. Iyer", room: "Block C · 301", day: "Tue", start: "09:00", end: "10:30", color: "blue" },
  { id: "c5", subject: "Probability & Statistics", code: "MA 220", instructor: "Dr. Mira Shah", room: "Block A · 208", day: "Tue", start: "11:00", end: "12:30", color: "mint" },
  { id: "c6", subject: "Database Systems", code: "CS 311", instructor: "Prof. S. Rao", room: "Block C · 204", day: "Tue", start: "14:00", end: "15:30", color: "rose" },
  { id: "c7", subject: "Computer Networks", code: "CS 308", instructor: "Dr. K. Menon", room: "Block B · 106", day: "Wed", start: "08:30", end: "10:00", color: "peach" },
  { id: "c8", subject: "Data Structures", code: "CS 204", instructor: "Dr. Mira Shah", room: "Block C · 204", day: "Wed", start: "10:30", end: "12:00", color: "mint" },
  { id: "c9", subject: "Design Studio", code: "DS 101", instructor: "Prof. A. Nair", room: "Innovation Hub", day: "Wed", start: "13:30", end: "15:30", color: "lilac" },
  { id: "c10", subject: "Operating Systems", code: "CS 302", instructor: "Prof. R. Iyer", room: "Block C · 301", day: "Thu", start: "09:00", end: "10:30", color: "blue" },
  { id: "c11", subject: "Database Systems", code: "CS 311", instructor: "Prof. S. Rao", room: "Block C · 204", day: "Thu", start: "11:00", end: "12:30", color: "rose" },
  { id: "c12", subject: "Digital Systems", code: "EC 215", instructor: "Dr. K. Menon", room: "Lab 3 · Block D", day: "Thu", start: "14:00", end: "16:00", color: "peach" },
  { id: "c13", subject: "Linear Algebra", code: "MA 201", instructor: "Prof. A. Nair", room: "Block A · 112", day: "Fri", start: "09:30", end: "11:00", color: "lilac" },
  { id: "c14", subject: "Computer Networks", code: "CS 308", instructor: "Dr. K. Menon", room: "Block B · 106", day: "Fri", start: "11:30", end: "13:00", color: "peach" },
  { id: "c15", subject: "Project Lab", code: "CS 390", instructor: "Prof. R. Iyer", room: "Innovation Hub", day: "Fri", start: "14:00", end: "16:00", color: "mint" },
];

const timeSlots = Array.from({ length: 9 }, (_, index) => index + 8);
const colorOptions = ["mint", "lilac", "peach", "blue", "rose"];

function formatTime(time: string) {
  const [hour, minute] = time.split(":").map(Number);
  const suffix = hour >= 12 ? "PM" : "AM";
  return `${hour % 12 || 12}:${String(minute).padStart(2, "0")} ${suffix}`;
}

function dateKey(date: Date) {
  return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
}

function mondayOf(date: Date) {
  const monday = new Date(date);
  monday.setDate(date.getDate() - ((date.getDay() + 6) % 7));
  return monday;
}

function getClassStyle(classItem: TimetableClass) {
  const [startHour, startMinute] = classItem.start.split(":").map(Number);
  const [endHour, endMinute] = classItem.end.split(":").map(Number);
  const startOffset = (startHour - 8) * 60 + startMinute;
  const duration = endHour * 60 + endMinute - startHour * 60 - startMinute;
  return { top: `${(startOffset / 60) * 72}px`, height: `${(duration / 60) * 72 - 4}px` };
}

const emptyForm = {
  subject: "",
  code: "",
  instructor: "",
  room: "",
  day: "Mon" as Weekday,
  start: "09:00",
  end: "10:00",
  color: "mint",
};

export function TimetableDashboard() {
  const [classes, setClasses] = useState(initialClasses);
  const [hydrated, setHydrated] = useState(false);
  const [selectedDay, setSelectedDay] = useState<Weekday | "All">("All");
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [calendarMonth, setCalendarMonth] = useState(() => new Date(baseMonday.getFullYear(), baseMonday.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState(todayDate);
  const calendarRef = useRef<HTMLDivElement>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");
  const [weekOffset, setWeekOffset] = useState(0);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("campus-timetable-classes");
      if (saved) setClasses(JSON.parse(saved) as TimetableClass[]);
    } catch {
      window.localStorage.removeItem("campus-timetable-classes");
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem("campus-timetable-classes", JSON.stringify(classes));
  }, [classes, hydrated]);

  useEffect(() => {
    if (!calendarOpen) return;
    const closeOnOutsideClick = (event: PointerEvent) => {
      if (event.target instanceof Node && !calendarRef.current?.contains(event.target)) setCalendarOpen(false);
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setCalendarOpen(false);
    };
    document.addEventListener("pointerdown", closeOnOutsideClick);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("pointerdown", closeOnOutsideClick);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [calendarOpen]);

  const visibleDays = selectedDay === "All" ? weekdays : [selectedDay];
  const filteredClasses = useMemo(() => classes.filter((classItem) => {
    const query = search.trim().toLowerCase();
    return (selectedDay === "All" || classItem.day === selectedDay)
      && (!query || `${classItem.subject} ${classItem.code} ${classItem.instructor} ${classItem.room}`.toLowerCase().includes(query));
  }), [classes, search, selectedDay]);
  const weekStart = new Date(baseMonday);
  weekStart.setDate(baseMonday.getDate() + weekOffset * 7);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 4);
  const monthStart = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), 1);
  const calendarStart = new Date(monthStart);
  calendarStart.setDate(1 - ((monthStart.getDay() + 6) % 7));
  const calendarDates = Array.from({ length: 42 }, (_, index) => {
    const date = new Date(calendarStart);
    date.setDate(calendarStart.getDate() + index);
    return date;
  });
  const datesByDay = new Map<Weekday, number>(weekdays.map((day, index) => {
    const date = new Date(weekStart);
    date.setDate(weekStart.getDate() + index);
    return [day, date.getDate()];
  }));
  const weekLabel = `${weekStart.toLocaleDateString("en", { month: "short", day: "numeric" })} – ${weekEnd.toLocaleDateString("en", { month: "short", day: "numeric", year: "numeric" })}`;

  function navigateWeek(direction: number) {
    const nextOffset = weekOffset + direction;
    const nextDate = new Date(selectedDate);
    nextDate.setDate(nextDate.getDate() + direction * 7);
    setWeekOffset(nextOffset);
    setSelectedDate(nextDate);
    setCalendarMonth(new Date(nextDate.getFullYear(), nextDate.getMonth(), 1));
  }

  function selectCalendarDate(date: Date) {
    const selectedWeek = mondayOf(date);
    const weekDifference = selectedWeek.getTime() - baseMonday.getTime();
    const nextOffset = Math.round(weekDifference / millisecondsPerWeek);
    const dayIndex = (date.getDay() + 6) % 7;
    setWeekOffset(nextOffset);
    setSelectedDate(date);
    setSelectedDay(dayIndex < weekdays.length ? weekdays[dayIndex] : "All");
    setCalendarMonth(new Date(date.getFullYear(), date.getMonth(), 1));
    setCalendarOpen(false);
  }

  function addClass(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (form.end <= form.start) {
      setError("End time needs to be later than start time.");
      return;
    }
    const overlaps = classes.some((item) => item.day === form.day && form.start < item.end && form.end > item.start);
    if (overlaps) {
      setError("That time overlaps another class on this day.");
      return;
    }
    setClasses((current) => [...current, { ...form, id: crypto.randomUUID() }]);
    setDialogOpen(false);
    setForm(emptyForm);
  }

  function exportCsv() {
    const rows = [["Day", "Subject", "Code", "Instructor", "Room", "Start", "End"], ...classes.map((item) => [item.day, item.subject, item.code, item.instructor, item.room, item.start, item.end])];
    const csv = rows.map((row) => row.map((value) => `"${value.replaceAll('"', '""')}"`).join(",")).join("\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    link.download = "campus-timetable.csv";
    link.click();
    URL.revokeObjectURL(link.href);
  }

  return (
    <main className={styles.appShell}>
      <aside className={styles.sidebar}>
        <a className={styles.brand} href="/timetable" aria-label="Campus home">
          <span className={styles.brandMark}><GraduationCap size={20} strokeWidth={1.8} /></span>
          <span>campus<span className={styles.brandDot}>.</span></span>
        </a>
        <div className={styles.termPicker}>
          <span className={styles.termIcon}><BookOpen size={16} /></span>
          <span><strong>Fall semester</strong><small>2026 · Year 2</small></span>
          <ChevronDown size={15} className={styles.termChevron} />
        </div>
        <p className={styles.navLabel}>YOUR SPACE</p>
        <nav className={styles.navigation} aria-label="Main navigation">
          <a className={`${styles.navItem} ${styles.navActive}`} href="#schedule"><CalendarDays size={17} />Timetable</a>
          <a className={styles.navItem} href="#classes"><BookOpen size={17} />My classes<span className={styles.navCount}>{new Set(classes.map((item) => item.code)).size}</span></a>
        </nav>
        <div className={styles.sidebarBottom}>
          <div className={styles.weeklyCard}>
            <span className={styles.weeklyIcon}><CalendarPlus size={16} /></span>
            <strong>Make room to learn.</strong>
            <p>Your week has <b>{classes.length} classes</b> on the calendar.</p>
          </div>
          <div className={styles.studentCard}>
            <span className={styles.studentAvatar}>AS</span>
            <span><strong>Alex Smith</strong><small>Computer Science</small></span>
            <ChevronDown size={15} className={styles.termChevron} />
          </div>
        </div>
      </aside>

      <section className={styles.mainColumn}>
        <header className={styles.topbar}>
          <div className={styles.breadcrumb}><span>My space</span><span className={styles.breadcrumbSlash}>/</span><strong>Timetable</strong></div>
          <div className={styles.topActions}>
            <button className={styles.exportButton} onClick={exportCsv}><Download size={15} /> <span>Export</span></button>
            <button className={styles.addButton} onClick={() => { setError(""); setDialogOpen(true); }}><Plus size={16} /> Add class</button>
          </div>
        </header>

        <div className={styles.content} id="schedule">
          <div className={styles.pageHeading}>
            <div>
              <div className={styles.eyebrow}><span className={styles.liveDot} /> FALL SEMESTER <span className={styles.eyebrowDivider}>/</span> WEEKLY OVERVIEW</div>
              <h1>Your week, <em>in rhythm.</em></h1>
              <p>One clear view of where you need to be and what you’re learning.</p>
            </div>
            <div className={styles.weekControl} ref={calendarRef}>
              <button type="button" className={styles.iconButton} aria-label="Previous week" onClick={() => navigateWeek(-1)}><ChevronLeft size={17} /></button>
              <button type="button" className={styles.weekRange} aria-haspopup="dialog" aria-expanded={calendarOpen} onClick={() => setCalendarOpen((open) => !open)}><CalendarDays size={15} />{weekLabel}{weekOffset === 0 && <span className={styles.thisWeek}>THIS WEEK</span>}</button>
              <button type="button" className={styles.iconButton} aria-label="Next week" onClick={() => navigateWeek(1)}><ChevronRight size={17} /></button>
              {calendarOpen && <div className={styles.datePicker} role="dialog" aria-label="Choose a date">
                <div className={styles.pickerHeader}>
                  <button type="button" className={styles.pickerMonthButton} aria-label="Previous month" onClick={() => setCalendarMonth((month) => new Date(month.getFullYear(), month.getMonth() - 1, 1))}><ChevronLeft size={16} /></button>
                  <strong aria-live="polite">{calendarMonth.toLocaleDateString("en", { month: "long", year: "numeric" })}</strong>
                  <button type="button" className={styles.pickerMonthButton} aria-label="Next month" onClick={() => setCalendarMonth((month) => new Date(month.getFullYear(), month.getMonth() + 1, 1))}><ChevronRight size={16} /></button>
                </div>
                <div className={styles.pickerGrid}>
                  {(["M", "T", "W", "T", "F", "S", "S"] as const).map((day, index) => <span className={styles.pickerWeekday} key={`${day}-${index}`}>{day}</span>)}
                  {calendarDates.map((date) => <button
                    type="button"
                    key={dateKey(date)}
                    className={`${styles.dateCell} ${date.getMonth() === calendarMonth.getMonth() ? "" : styles.otherMonthDate} ${dateKey(date) === dateKey(selectedDate) ? styles.selectedDate : ""} ${dateKey(date) === dateKey(todayDate) ? styles.todayDate : ""}`}
                    aria-label={date.toLocaleDateString("en", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
                    aria-pressed={dateKey(date) === dateKey(selectedDate)}
                    onClick={() => selectCalendarDate(date)}
                  >{date.getDate()}</button>)}
                </div>
                <div className={styles.pickerFooter}><span>Choose any date</span><button type="button" onClick={() => selectCalendarDate(todayDate)}>Today</button></div>
              </div>}
            </div>
          </div>

          <div className={styles.statsRow}>
            <div className={styles.stat}><span className={styles.statIcon}><BookOpen size={16} /></span><span><strong>{new Set(classes.map((item) => item.code)).size}</strong><small>COURSES</small></span></div>
            <div className={styles.stat}><span className={`${styles.statIcon} ${styles.statIconGreen}`}><Clock3 size={16} /></span><span><strong>{classes.length}</strong><small>CLASSES THIS WEEK</small></span></div>
            <div className={styles.stat}><span className={`${styles.statIcon} ${styles.statIconCoral}`}><MapPin size={16} /></span><span><strong>{new Set(classes.map((item) => item.room)).size}</strong><small>ROOMS TO KNOW</small></span></div>
            <div className={styles.statsNote}><span className={styles.noteMark}>✳</span><span>Leave a little space<br />between the big ideas.</span></div>
          </div>

          <section className={styles.schedulePanel} id="classes" aria-label="Weekly class schedule">
            <div className={styles.scheduleToolbar}>
              <div className={styles.viewTabs} role="group" aria-label="Filter schedule by day">
                <button className={`${styles.viewTab} ${selectedDay === "All" ? styles.viewTabActive : ""}`} onClick={() => setSelectedDay("All")}>Week view</button>
                {weekdays.map((day) => <button key={day} className={`${styles.viewTab} ${selectedDay === day ? styles.viewTabActive : ""}`} onClick={() => setSelectedDay(day)}>{day}</button>)}
              </div>
              <label className={styles.searchBox}>
                <Search size={15} />
                <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Find a class..." aria-label="Search classes" />
                {search && <button type="button" onClick={() => setSearch("")} aria-label="Clear search"><X size={13} /></button>}
              </label>
            </div>

            <div className={`${styles.calendar} ${selectedDay !== "All" ? styles.singleDay : ""}`}>
              <div className={styles.dayHeaderRow}>
                <div className={styles.timeHeading}>GMT+5:30</div>
                {visibleDays.map((day) => <div className={`${styles.dayHeading} ${weekOffset === 0 && day === "Wed" ? styles.todayHeading : ""}`} key={day}>
                  <span>{day.toUpperCase()}</span><strong>{datesByDay.get(day)}</strong>{weekOffset === 0 && day === "Wed" && <i>Today</i>}
                </div>)}
              </div>
              <div className={styles.calendarBody}>
                <div className={styles.timeColumn}>{timeSlots.map((hour) => <span key={hour}>{hour % 12 || 12} {hour >= 12 ? "PM" : "AM"}</span>)}</div>
                <div className={styles.dayColumns} style={{ gridTemplateColumns: `repeat(${visibleDays.length}, minmax(0, 1fr))` }}>
                  {visibleDays.map((day) => <div className={`${styles.dayColumn} ${weekOffset === 0 && day === "Wed" ? styles.todayColumn : ""}`} key={day}>
                    {timeSlots.map((hour) => <div className={styles.hourLine} key={hour} />)}
                    {filteredClasses.filter((item) => item.day === day).map((item) => <article className={`${styles.classCard} ${styles[`tone_${item.color}`]}`} style={getClassStyle(item)} key={item.id}>
                      <button className={styles.deleteClass} title={`Remove ${item.subject}`} aria-label={`Remove ${item.subject}`} onClick={() => setClasses((current) => current.filter((entry) => entry.id !== item.id))}><Trash2 size={13} /></button>
                      <strong>{item.subject}</strong>
                      <span className={styles.classCode}>{item.code}</span>
                      <span className={styles.classMeta}><Clock3 size={11} />{formatTime(item.start)} – {formatTime(item.end)}</span>
                      <span className={styles.classMeta}><MapPin size={11} />{item.room}</span>
                    </article>)}
                  </div>)}
                </div>
              </div>
            </div>
            {filteredClasses.length === 0 && <div className={styles.noResults}>No classes match that search. Try another subject or instructor.</div>}

            <footer className={styles.scheduleFooter}>
              <span><span className={styles.legendDot} /> {classes.length} sessions scheduled</span>
              <span><UserRound size={13} /> Alex Smith · CS Year 2</span>
            </footer>
          </section>

          <div className={styles.bottomNote}><span><Check size={14} /></span><p><strong>All caught up.</strong> Your timetable is looking good. Add a class whenever your schedule changes.</p><button onClick={() => { setError(""); setDialogOpen(true); }}>Add a class <ChevronRight size={14} /></button></div>
        </div>
      </section>

      {dialogOpen && <div className={styles.modalBackdrop} onMouseDown={(event) => { if (event.target === event.currentTarget) setDialogOpen(false); }}>
        <section className={styles.modal} role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <div className={styles.modalHeader}><div><span className={styles.modalIcon}><CalendarPlus size={18} /></span><div><span className={styles.eyebrow}>UPDATE YOUR WEEK</span><h2 id="modal-title">Add a class</h2></div></div><button className={styles.iconButton} aria-label="Close dialog" onClick={() => setDialogOpen(false)}><X size={17} /></button></div>
          <form onSubmit={addClass} className={styles.classForm}>
            <label>Class name<input required maxLength={60} placeholder="e.g. Human Computer Interaction" value={form.subject} onChange={(event) => setForm({ ...form, subject: event.target.value })} /></label>
            <div className={styles.formPair}><label>Course code<input required maxLength={16} placeholder="CS 320" value={form.code} onChange={(event) => setForm({ ...form, code: event.target.value })} /></label><label>Day<select value={form.day} onChange={(event) => setForm({ ...form, day: event.target.value as Weekday })}>{weekdays.map((day) => <option key={day} value={day}>{day}</option>)}</select></label></div>
            <div className={styles.formPair}><label>Starts<input type="time" min="08:00" max="17:00" required value={form.start} onChange={(event) => setForm({ ...form, start: event.target.value })} /></label><label>Ends<input type="time" min="08:00" max="17:00" required value={form.end} onChange={(event) => setForm({ ...form, end: event.target.value })} /></label></div>
            <div className={styles.formPair}><label>Instructor<input required maxLength={50} placeholder="Instructor name" value={form.instructor} onChange={(event) => setForm({ ...form, instructor: event.target.value })} /></label><label>Room<input required maxLength={40} placeholder="Building · room" value={form.room} onChange={(event) => setForm({ ...form, room: event.target.value })} /></label></div>
            <fieldset className={styles.colorField}><legend>Calendar color</legend><div>{colorOptions.map((color) => <button key={color} type="button" className={`${styles.colorSwatch} ${styles[`swatch_${color}`]} ${form.color === color ? styles.swatchSelected : ""}`} aria-label={`${color} color`} aria-pressed={form.color === color} onClick={() => setForm({ ...form, color })} />)}</div></fieldset>
            {error && <p className={styles.formError}>{error}</p>}
            <div className={styles.modalActions}><button className={styles.cancelButton} type="button" onClick={() => setDialogOpen(false)}>Cancel</button><button className={styles.addButton} type="submit"><Plus size={15} /> Add to timetable</button></div>
          </form>
        </section>
      </div>}
    </main>
  );
}