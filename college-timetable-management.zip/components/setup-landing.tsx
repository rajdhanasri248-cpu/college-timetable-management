"use client";

import { ArrowDown, ArrowUpRight, Database, KeyRound, ShieldCheck, Sparkles } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { DotStage } from "@/components/dot-stage";
import { previewDetails, previewDots } from "@/lib/preview-dots";
import type { Dot } from "@/types/dots";

export function SetupLanding({ message, authAvailable = false, selectedDotSlug }: { message?: string; authAvailable?: boolean; selectedDotSlug?: string }) {
  const router = useRouter();
  const selectedDot = previewDots.find((dot) => dot.slug === selectedDotSlug);
  const selectedDetails = selectedDot ? previewDetails[selectedDot.slug] : undefined;
  const showDot = (dot: Dot) => router.push(`/dots/${dot.slug}`);

  return (
    <main className="setup-page">
      <header className="setup-top"><Link className="dots-wordmark" href="/"><span className="wordmark-glyph"><Sparkles size={15} /></span>DOTS</Link><span className="setup-top-note">{selectedDot ? <><Link href="/">MY DOTS</Link><span> / </span>{selectedDot.name.toUpperCase()}</> : "A PERSONAL TEAM, MADE OF LITTLE THINGS"}</span></header>
      <section className="setup-hero">
        <div className="setup-copy">
          <span className="eyebrow">{selectedDot ? `${selectedDot.name.toUpperCase()} / ${selectedDot.role.toUpperCase()}` : "FOUR COMPANIONS. ONE QUIETER SPACE."}</span>
          <h1>{selectedDot ? <>Inside <em>{selectedDot.name}.</em></> : <>Your little team<br />is <em>taking shape.</em></>}</h1>
          <p>{selectedDetails?.intro ?? "Thoughtful companions for the parts of life you want a hand with. Original, tactile, and yours to shape."}</p>
          <a className="setup-link" href={selectedDot ? "#dot-workspace" : "#connect"}>{selectedDot ? `Explore ${selectedDot.name}'s space` : "Connect your workspace"} <ArrowDown size={14} /></a>
        </div>
        <div className="setup-stage-wrap"><DotStage dots={selectedDot ? [selectedDot] : previewDots} activeId={selectedDot?.id} preview={!selectedDot} onSelect={showDot} /><div className="preview-label"><span>{selectedDot ? `${selectedDot.name.toUpperCase()} / COMPANION PREVIEW` : "COMPANION STUDIES"}</span><span>{selectedDot ? "01 / READ-ONLY" : "01—04 / ORIGINAL FORMS"}</span></div></div>
      </section>
      <section className="companion-strip" aria-label="Dot companion roles">
        {previewDots.map((dot) => <button className={`companion-caption ${dot.slug === selectedDotSlug ? "companion-caption-active" : ""}`} key={dot.slug} onClick={() => showDot(dot)} aria-label={`Open ${dot.name}, ${dot.role}`}><span className="companion-caption-dot" style={{ background: dot.color }} /><div><strong>{dot.name}</strong><span>{dot.role}</span></div><ArrowUpRight size={13} className="companion-caption-arrow" /></button>)}
      </section>
      {selectedDot && selectedDetails && <section className="dot-preview-workspace" id="dot-workspace">
        <div className="preview-workspace-copy"><span className="eyebrow">A LITTLE MORE ABOUT {selectedDot.name.toUpperCase()}</span><h2>{selectedDot.description}</h2><p>{selectedDetails.intro}</p><div className="preview-capabilities">{selectedDetails.focus.map((focus) => <span key={focus}><i style={{ background: selectedDot.color }} />{focus}</span>)}</div><div className="preview-chat-gate"><Sparkles size={15} /><span><strong>This is a character preview.</strong><small>Sign in and connect an AI provider to start a real, private conversation.</small></span></div></div>
        <div className="preview-workspace-side"><span className="eyebrow">YOUR COMPANION</span><span className="preview-side-name" style={{ color: selectedDot.color }}>{selectedDot.name}</span><span className="preview-side-role">{selectedDot.role}</span><Link href="/#connect" className="preview-connect-link">Connect workspace <ArrowUpRight size={13} /></Link></div>
      </section>}
      <section className="setup-connect" id="connect">
        <div className="connect-heading"><span className="eyebrow">BEFORE YOUR DOTS CAN REMEMBER</span><h2>Connect the real things.</h2><p>No demo data here. Your conversations and activity stay attached to your own account.</p></div>
        <div className="setup-prereqs">
          <div><Database size={17} /><span><strong>Supabase</strong><small>Auth, PostgreSQL, row-level security</small></span><span className="prereq-state">REQUIRED</span></div>
          <div><KeyRound size={17} /><span><strong>OpenAI API</strong><small>Server-side streamed companion replies</small></span><span className="prereq-state">REQUIRED</span></div>
          <div><ShieldCheck size={17} /><span><strong>Your data, scoped</strong><small>Private by default with per-user policies</small></span><span className="prereq-state prereq-ready">DESIGNED IN</span></div>
        </div>
        {message && <p className="setup-notice" role="status">{message}</p>}
        <div className="setup-next"><span>ADD CREDENTIALS TO <code>.env.local</code>, THEN APPLY THE SQL MIGRATION.</span>{authAvailable && <Link href="/login">Continue to sign in <ArrowUpRight size={14} /></Link>}</div>
      </section>
      <footer className="setup-footer"><span>DOTS <i>·</i> A SMALLER KIND OF SUPPORT</span><span>PRIVATE BY DESIGN</span></footer>
    </main>
  );
}