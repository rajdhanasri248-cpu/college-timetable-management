# DOTS

An early vertical slice for a private multi-companion workspace. The current build includes Supabase email authentication, signup-time provisioning of four Dots, user-scoped PostgreSQL policies, persisted tasks, a realtime companion room, and server-side streamed OpenAI Responses API chat. Nova can retrieve her saved goals/tasks and can create a goal or task when the user explicitly asks. It is not the full production platform described in the product brief; see the current scope below.

## Run locally

1. Install Node.js 20.9 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and fill in the Supabase project URL, anon key, service-role key, and OpenAI API key. Keep `.env.local` private.
4. Apply `supabase/migrations/202610010001_initial_dots.sql` to the Supabase project using the SQL editor or Supabase CLI.
5. In Supabase Auth, configure email confirmation and add `http://localhost:3000/auth/callback` as an allowed redirect URL.
6. Run `npm run dev` and open `http://localhost:3000`.

Without Supabase credentials, the home route shows an explicitly labeled character preview and setup requirements. It does not create demo users, fake messages, or synthetic activity. OpenAI chat remains unavailable until both the OpenAI key and server-only Supabase key are configured.

## Validation

- `npm run typecheck`
- `npm run build`
- `GET /health`

## Current scope

- Auth: Supabase email/password signup and sign-in; Google OAuth is not configured.
- Companions: four original Three.js plush-inspired forms; stored Dot state drives idle, listening, thinking, responding, working, waiting, completed, paused, and error movement variations. Signup provisions IDLE Dots.
- Chat: per-Dot conversation history, server-only OpenAI Responses API calls, SSE text/activity events, persisted user and assistant messages, state transitions, and activity records. Nova has model-selected tools for reading Nova-scoped goals/tasks and for explicitly requested goal/task creation. No live internship search or skills profile provider is connected; Nova is instructed not to claim one exists.
- Tasks: owner-scoped create, complete, and list operations.
- Persistence/security: initial schema and RLS for profiles, Dots, conversations, messages, tasks, goals, memories, and activity logs.

## Not implemented yet

This slice does not yet include goals and milestones UI, daily plans, journal/mood/reflection flows, approved-memory capture and retrieval, embeddings/pgvector, file or voice pipelines, OAuth integrations, background workers, rate limiting, billing/usage accounting, data export/deletion workflows, or automated integration/E2E tests. The migration creates initial task/goal/memory tables but does not imply those product flows are complete. Run security and cross-account integration tests against a configured Supabase project before production use.

## Deployment notes

The Next.js app can be deployed to Vercel. Configure the same environment variables in the deployment platform, run the SQL migration against the production Supabase project, and set the production auth callback URL. Never expose `SUPABASE_SERVICE_ROLE_KEY` or `OPENAI_API_KEY` as `NEXT_PUBLIC_*` variables. Background jobs and external integrations need separate worker/provider setup before enabling those features.