export type DotState =
  | "IDLE"
  | "LISTENING"
  | "THINKING"
  | "RESPONDING"
  | "WORKING"
  | "WAITING"
  | "COMPLETED"
  | "PAUSED"
  | "ERROR";

export type Dot = {
  id: string;
  user_id: string;
  name: string;
  slug: string;
  role: string;
  description: string;
  color: string;
  avatar_config: { body?: string; accessory?: string };
  status?: DotState;
  status_detail?: string | null;
  last_active_at?: string | null;
};

export type Task = {
  id: string;
  title: string;
  description: string | null;
  status: "TODO" | "IN_PROGRESS" | "WAITING" | "COMPLETED" | "CANCELLED";
  priority: "LOW" | "MEDIUM" | "HIGH";
  deadline: string | null;
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
};