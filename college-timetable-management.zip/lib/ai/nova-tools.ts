import OpenAI from "openai";
import { z } from "zod";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const careerGoalSchema = z.object({
  title: z.string().trim().min(3).max(120),
  description: z.string().trim().max(1000).nullable(),
  target_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable(),
});

const taskSchema = z.object({
  title: z.string().trim().min(2).max(160),
  description: z.string().trim().max(1000).nullable(),
  priority: z.enum(["LOW", "MEDIUM", "HIGH"]),
  deadline: z.string().datetime().nullable(),
});

const nullableText = { type: ["string", "null"] };

export const novaTools: OpenAI.Responses.FunctionTool[] = [
  {
    type: "function",
    name: "get_career_context",
    description: "Retrieve the signed-in user's saved career goals and open tasks assigned to Nova. Use this before tailoring advice to saved plans. It does not contain an inferred skills profile.",
    strict: true,
    parameters: { type: "object", properties: {}, required: [], additionalProperties: false },
  },
  {
    type: "function",
    name: "create_career_goal",
    description: "Save a career goal only when the user explicitly asks Nova to create or save a goal. Do not call for a discussion or suggestion alone.",
    strict: true,
    parameters: {
      type: "object",
      properties: {
        title: { type: "string", minLength: 3, maxLength: 120 },
        description: nullableText,
        target_date: { ...nullableText, description: "Target date in YYYY-MM-DD format, or null if the user did not provide one." },
      },
      required: ["title", "description", "target_date"],
      additionalProperties: false,
    },
  },
  {
    type: "function",
    name: "create_task",
    description: "Create a task for Nova only when the user explicitly asks to add, save, or track an action. Do not create tasks for advice or brainstorming alone.",
    strict: true,
    parameters: {
      type: "object",
      properties: {
        title: { type: "string", minLength: 2, maxLength: 160 },
        description: nullableText,
        priority: { type: "string", enum: ["LOW", "MEDIUM", "HIGH"] },
        deadline: { ...nullableText, description: "Deadline as an ISO 8601 timestamp, or null if the user did not provide one." },
      },
      required: ["title", "description", "priority", "deadline"],
      additionalProperties: false,
    },
  },
];

type NovaToolContext = {
  admin: ReturnType<typeof createSupabaseAdminClient>;
  userId: string;
  dotId: string;
  dotName: string;
};

export async function executeNovaTool(name: string, rawArguments: string, context: NovaToolContext) {
  if (name === "get_career_context") {
    const args = JSON.parse(rawArguments) as unknown;
    if (!z.object({}).strict().safeParse(args).success) {
      return { activity: "Checking saved career context", output: JSON.stringify({ ok: false, error: "This tool takes no arguments." }) };
    }

    const [{ data: goals, error: goalsError }, { data: tasks, error: tasksError }] = await Promise.all([
      context.admin.from("goals").select("title,description,target_date,progress,status").eq("user_id", context.userId).eq("dot_id", context.dotId).eq("status", "ACTIVE").limit(12),
      context.admin.from("tasks").select("title,description,status,priority,deadline").eq("user_id", context.userId).eq("dot_id", context.dotId).not("status", "in", "(COMPLETED,CANCELLED)").limit(20),
    ]);

    if (goalsError || tasksError) {
      return { activity: "Checking saved career context", output: JSON.stringify({ ok: false, error: "Saved career context could not be loaded." }) };
    }

    return {
      activity: "Checking Nova's saved goals and tasks",
      output: JSON.stringify({ goals: goals ?? [], openTasks: tasks ?? [], skillsProfile: null }),
    };
  }

  if (name === "create_career_goal") {
    const parsed = careerGoalSchema.safeParse(JSON.parse(rawArguments));
    if (!parsed.success) return { activity: "Validating the requested career goal", output: JSON.stringify({ ok: false, error: "Goal details were invalid; ask the user to clarify." }) };

    const { data, error } = await context.admin.from("goals").insert({
      user_id: context.userId,
      dot_id: context.dotId,
      title: parsed.data.title,
      description: parsed.data.description,
      target_date: parsed.data.target_date,
    }).select("id,title,target_date").single();

    if (error || !data) return { activity: "Saving the requested career goal", output: JSON.stringify({ ok: false, error: "The goal could not be saved." }) };
    await context.admin.from("activity_logs").insert({ user_id: context.userId, dot_id: context.dotId, event_type: "GOAL_CREATED", description: `${context.dotName} saved a career goal.` });
    return { activity: "Saving the career goal you requested", output: JSON.stringify({ ok: true, goal: data }) };
  }

  if (name === "create_task") {
    const parsed = taskSchema.safeParse(JSON.parse(rawArguments));
    if (!parsed.success) return { activity: "Validating the requested task", output: JSON.stringify({ ok: false, error: "Task details were invalid; ask the user to clarify." }) };

    const { data, error } = await context.admin.from("tasks").insert({
      user_id: context.userId,
      dot_id: context.dotId,
      title: parsed.data.title,
      description: parsed.data.description,
      priority: parsed.data.priority,
      deadline: parsed.data.deadline,
    }).select("id,title,status,priority,deadline").single();

    if (error || !data) return { activity: "Saving the requested career task", output: JSON.stringify({ ok: false, error: "The task could not be saved." }) };
    await context.admin.from("activity_logs").insert({ user_id: context.userId, dot_id: context.dotId, event_type: "TASK_CREATED", description: `${context.dotName} saved a career task.` });
    return { activity: "Saving the task you requested", output: JSON.stringify({ ok: true, task: data }) };
  }

  return { activity: "Checking Nova's tools", output: JSON.stringify({ ok: false, error: "That tool is not available." }) };
}