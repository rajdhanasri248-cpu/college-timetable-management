import type { Dot } from "@/types/dots";

export const previewDots: Dot[] = [
  { id: "mira-preview", user_id: "", name: "Mira", slug: "mira", role: "Mental Wellbeing", description: "A gentle space for reflection and small check-ins.", color: "#e990b5", avatar_config: { body: "soft", accessory: "flower" } },
  { id: "pixel-preview", user_id: "", name: "Pixel", slug: "pixel", role: "Coding", description: "A curious partner for code, DSA, and projects.", color: "#83c5a1", avatar_config: { body: "wide", accessory: "round-glasses" } },
  { id: "nova-preview", user_id: "", name: "Nova", slug: "nova", role: "Career & Internship", description: "A focused companion for the work you want to do.", color: "#a38ae2", avatar_config: { body: "tall", accessory: "star" } },
  { id: "mint-preview", user_id: "", name: "Mint", slug: "mint", role: "Personal Planning", description: "A calm place to shape a plan that can flex.", color: "#e5a076", avatar_config: { body: "pear", accessory: "leaf" } },
];

const dotOrder: Record<string, number> = { mira: 0, pixel: 1, nova: 2, mint: 3 };

export function orderDots(dots: Dot[]) {
  return [...dots].sort((left, right) => (dotOrder[left.slug] ?? 99) - (dotOrder[right.slug] ?? 99));
}

export const previewDetails: Record<string, { intro: string; focus: string[] }> = {
  mira: { intro: "A warm, unhurried space to reflect, journal, or sort through a full day.", focus: ["Daily reflection", "Gentle check-ins", "Wellbeing habits"] },
  nova: { intro: "A clear-eyed partner for career plans, applications, and the next opportunity.", focus: ["Career direction", "Internship applications", "Interview practice"] },
  pixel: { intro: "A curious, precise companion for coding questions, DSA practice, and projects.", focus: ["Code & debugging", "DSA practice", "Project progress"] },
  mint: { intro: "A practical planning partner for turning a crowded day into a few doable steps.", focus: ["Daily planning", "Tasks & routines", "Flexible priorities"] },
};